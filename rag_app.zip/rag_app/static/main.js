/* ======================================================
   WayneTech RAG Chatbot — main.js (FULL, feature-complete)
   - Background particles
   - Hero typing
   - Scroll progress & reveal
   - Theme toggle hook
   - Chat overlay + upload console (drag/drop)
   - XHR upload with progress + fallback
   - Chat -> POST /ask
   - Voice recognition
   - Save / copy / clear chat utilities (if buttons exist)
   ====================================================== */

'use strict';

/* -------------------------
   Cached DOM references
   ------------------------- */
const canvas = document.getElementById('bgCanvas');
const typingText = document.getElementById('typing-text');
const scrollProgress = document.getElementById('scroll-progress');

const chatOverlay = document.getElementById('chat-overlay');
const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

const uploadArea = document.getElementById('upload-area');
const fileInput = document.getElementById('fileInput');
const fileList = document.getElementById('file-list');
const uploadProgressWrap = document.getElementById('upload-progress');
const progressBar = document.getElementById('progress-bar');
const uploadStatus = document.getElementById('upload-status');
const uploadClearBtn = document.getElementById('upload-clear');

const micBtn = document.getElementById('mic-btn');
const retrievedEl = document.getElementById('retrieved');

const yearEl = document.getElementById('year');

/* Defensive / no-op fallbacks */
function elSafe(id){ return document.getElementById(id) || null; }

/* ---------------
   BACKGROUND PARTICLES
   --------------- */
(function particlesBackground() {
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let DPR = Math.max(1, window.devicePixelRatio || 1);
  let particles = [];
  const COUNT = 80;

  function resize() {
    DPR = Math.max(1, window.devicePixelRatio || 1);
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    canvas.width = Math.floor(w * DPR);
    canvas.height = Math.floor(h * DPR);
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    initParticles();
  }

  function rand(min, max){ return Math.random()*(max-min)+min; }

  function initParticles(){
    particles = [];
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    for (let i=0;i<COUNT;i++){
      particles.push({
        x: rand(0, w),
        y: rand(0, h),
        r: rand(0.6, 3.2),
        vx: rand(-0.25, 0.25),
        vy: rand(-0.12, 0.12),
        hue: rand(150, 210),
        alpha: rand(0.08, 0.22)
      });
    }
  }

  function draw(){
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    // subtle dark fill (creates motion trail effect)
    ctx.fillStyle = 'rgba(13,17,23,0.28)';
    ctx.fillRect(0,0,w,h);

    for (const p of particles){
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < -20) p.x = w + 20;
      if (p.x > w + 20) p.x = -20;
      if (p.y < -20) p.y = h + 20;
      if (p.y > h + 20) p.y = -20;

      const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r*8);
      grd.addColorStop(0, `hsla(${p.hue},95%,55%,${p.alpha})`);
      grd.addColorStop(1, `hsla(${p.hue},95%,55%,0)`);
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r*6, 0, Math.PI*2);
      ctx.fill();
    }
    requestAnimationFrame(draw);
  }

  window.addEventListener('resize', resize);
  resize();
  draw();
})();

/* ---------------
   HERO TYPING
   --------------- */
(function heroTyping(){
  if (!typingText) return;
  const lines = [
    'Retrieving knowledge from your documents...',
    'Generating grounded, factual responses...',
    'WayneTech AI — Your knowledge, served precisely.'
  ];
  let li = 0, ci = 0, forward = true;

  function step(){
    const line = lines[li];
    typingText.textContent = line.slice(0, ci);
    if (forward){
      ci++;
      if (ci > line.length){
        forward = false;
        setTimeout(step, 1200);
        return;
      }
    } else {
      ci--;
      if (ci < 0){
        forward = true;
        li = (li + 1) % lines.length;
      }
    }
    setTimeout(step, forward ? 36 : 22);
  }
  step();
})();

/* ---------------
   SCROLL PROGRESS & REVEAL
   --------------- */
(function scrollHelpers(){
  if (scrollProgress){
    window.addEventListener('scroll', ()=>{
      const d = document.documentElement;
      const pct = (d.scrollTop / (d.scrollHeight - d.clientHeight)) * 100 || 0;
      scrollProgress.style.width = pct + '%';
    }, {passive:true});
  }

  const observer = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if (e.isIntersecting) e.target.classList.add('visible');
    });
  }, { threshold: 0.12 });

  document.querySelectorAll('[data-fade]').forEach(el => observer.observe(el));
})();

/* ---------------
   THEME TOGGLE (hook)
   --------------- */
(function themeHook(){
  const themeToggle = document.getElementById('theme-toggle');
  if (!themeToggle) return;
  const THEME_KEY = 'waynetech_theme';
  function applyTheme(t){
    if (t === 'dark') document.body.classList.remove('light');
    else document.body.classList.add('light');
    localStorage.setItem(THEME_KEY, t);
  }
  const saved = localStorage.getItem(THEME_KEY) || 'dark';
  applyTheme(saved);
  themeToggle.addEventListener('click', ()=>{
    const next = (localStorage.getItem(THEME_KEY) === 'dark') ? 'light' : 'dark';
    applyTheme(next);
  });
})();

/* ---------------
   CHAT OPEN / CLOSE
   --------------- */
function openChat(){
  if (!chatOverlay) return;
  chatOverlay.classList.remove('hidden');
  chatOverlay.classList.add('visible');
  // reset upload status visually if present
  if (uploadStatus) uploadStatus.textContent = '';
  // seed chat box with welcome message only if empty
  if (chatBox && chatBox.children.length === 0){
    appendBotMessage('🧠 RAG Assistant online. Upload docs to begin (or ask a question).');
  }
  // focus input
  setTimeout(()=> userInput?.focus(), 300);
}
function closeChat(){
  if (!chatOverlay) return;
  chatOverlay.classList.remove('visible');
  setTimeout(()=> chatOverlay.classList.add('hidden'), 350);
}
window.openChat = openChat;
window.closeChat = closeChat;

/* ---------------
   UPLOAD AREA (drag/drop + XHR progress + preview)
   --------------- */
(function uploadConsole(){
  if (!uploadArea || !fileInput) return;

  // local state
  let lastFiles = null;
  let currentXHR = null;

  // helpers
  function humanSize(bytes){
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024*1024) return (bytes/1024).toFixed(1) + ' KB';
    return (bytes/(1024*1024)).toFixed(2) + ' MB';
  }
  function clearFileList(){
    if (fileList) fileList.innerHTML = '';
    lastFiles = null;
  }

  // click to open file dialog
  uploadArea.addEventListener('click', ()=> fileInput.click());

  // drag effects
  uploadArea.addEventListener('dragover', (e)=>{
    e.preventDefault();
    uploadArea.classList.add('dragover');
  });
  uploadArea.addEventListener('dragleave', ()=>{
    uploadArea.classList.remove('dragover');
  });
  uploadArea.addEventListener('drop', (e)=>{
    e.preventDefault();
    uploadArea.classList.remove('dragover');
    const dt = e.dataTransfer;
    if (dt && dt.files && dt.files.length) handleFiles(dt.files);
  });

  // file input change
  fileInput.addEventListener('change', ()=> {
    if (fileInput.files && fileInput.files.length) handleFiles(fileInput.files);
  });

  // Clear uploads button (optional in HTML)
  uploadClearBtn?.addEventListener('click', ()=> {
    // abort any in-flight xhr
    if (currentXHR) { currentXHR.abort(); currentXHR = null; }
    clearFileList();
    if (uploadStatus) uploadStatus.textContent = '';
    if (uploadProgressWrap) uploadProgressWrap.classList.add('hidden');
  });

  // Display files
  function renderFileList(files){
    lastFiles = files;
    if (!fileList) return;
    fileList.innerHTML = '';
    [...files].forEach(file => {
      const li = document.createElement('li');
      li.className = 'upload-file-item';
      const name = document.createElement('span');
      name.textContent = file.name;
      const size = document.createElement('small');
      size.textContent = humanSize(file.size);
      size.style.opacity = 0.8;
      li.appendChild(name);
      li.appendChild(size);
      fileList.appendChild(li);
    });
  }

  // show preview (for txt)
  async function tryPreview(files){
    const first = files[0];
    if (!first) return;
    const ext = (first.name.split('.').pop() || '').toLowerCase();
    if (ext === 'txt'){
      try{
        const text = await first.text();
        const preview = document.createElement('div');
        preview.className = 'file-preview';
        preview.textContent = text.slice(0, 1000) + (text.length > 1000 ? '\n\n... (truncated)' : '');
        if (uploadArea && preview) {
          // show as small node below list
          if (uploadStatus) uploadStatus.insertAdjacentElement('afterend', preview);
          else uploadArea.appendChild(preview);
        }
      }catch(e){ /* ignore preview errors */ }
    }
  }

  // handle files and upload
  async function handleFiles(files){
    renderFileList(files);
    tryPreview(files);
    if (uploadStatus) uploadStatus.textContent = '⏳ Preparing to upload...';
    if (uploadProgressWrap) uploadProgressWrap.classList.remove('hidden');
    if (progressBar) progressBar.style.width = '0%';

    // Build FormData
    const fd = new FormData();
    for (const f of files) fd.append('files', f);

    // Use XHR to get upload progress events
    const xhr = new XMLHttpRequest();
    currentXHR = xhr;
    xhr.open('POST', '/load_docs', true);

    // progress event
    xhr.upload.onprogress = function(evt){
      if (!evt.lengthComputable) return;
      const pct = Math.round((evt.loaded / evt.total) * 100);
      if (progressBar) progressBar.style.width = pct + '%';
      if (uploadStatus) uploadStatus.textContent = `Uploading... ${pct}%`;
    };

    // onload
    xhr.onload = function(){
      currentXHR = null;
      if (xhr.status >= 200 && xhr.status < 300){
        try{
          const data = JSON.parse(xhr.responseText);
          if (uploadStatus) uploadStatus.textContent = `✅ ${data.message || 'Upload complete.'}`;
          if (progressBar) progressBar.style.width = '100%';
          // optional: display retrieved snippet placeholders
          if (retrievedEl) retrievedEl.textContent = '(Documents loaded. Ready for queries.)';
        } catch(err){
          if (uploadStatus) uploadStatus.textContent = '✅ Upload complete (no JSON response)';
        }
      } else {
        if (uploadStatus) uploadStatus.textContent = `❌ Upload failed (${xhr.status})`;
      }
      // hide progress after short delay
      setTimeout(()=> uploadProgressWrap?.classList.add('hidden'), 1200);
    };

    // onerror
    xhr.onerror = function(){
      currentXHR = null;
      if (uploadStatus) uploadStatus.textContent = '❌ Upload error. Check network / backend.';
      uploadProgressWrap?.classList.add('hidden');
    };

    // timeout fallback: if progress events not firing, simulate progress until done
    let fakeInterval = null;
    const useFakeProgress = false; // we use real XHR unless environment blocks it
    if (useFakeProgress){
      let fake = 0;
      fakeInterval = setInterval(()=>{
        fake = Math.min(90, fake + Math.random()*12);
        if (progressBar) progressBar.style.width = fake + '%';
      }, 200);
    }

    try{
      xhr.send(fd);
    } catch (err){
      currentXHR = null;
      if (fakeInterval) clearInterval(fakeInterval);
      if (uploadStatus) uploadStatus.textContent = '❌ Upload failed (exception).';
      console.error('Upload send error', err);
    }
  } // handleFiles end

})();

/* ---------------
   CHAT: send -> /ask  (with "typing" placeholder)
   --------------- */
async function sendMessage(){
  if (!userInput || !chatBox) return;
  const text = userInput.value?.trim();
  if (!text) return;
  userInput.value = '';
  appendUserMessage(text);
  // show a typing bot message
  const typingId = appendBotTyping();

  // If user uploaded docs, server uses them; else server might reply that no docs loaded.
  try {
    const res = await fetch('/ask', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ query: text })
    });
    if (!res.ok){
      removeElementById(typingId);
      appendBotMessage(`❌ Server error: ${res.status}`);
      return;
    }
    const json = await res.json();
    removeElementById(typingId);
    const answer = (json && json.answer) ? json.answer : '(No answer returned)';
    appendBotMessage(answer);

    // optionally show retrieved context returned by server
    if (json && json.retrieved && retrievedEl) {
      retrievedEl.textContent = json.retrieved;
    }

  } catch (err){
    removeElementById(typingId);
    appendBotMessage('❌ Could not reach backend. Check server.');
    console.error('Chat send error', err);
  }
}
window.sendMessage = sendMessage;

/* message helper functions */
function appendUserMessage(text){
  if (!chatBox) return;
  const wrapper = document.createElement('div');
  wrapper.className = 'user-message';
  wrapper.textContent = text;
  chatBox.appendChild(wrapper);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function appendBotMessage(text){
  if (!chatBox) return;
  const wrapper = document.createElement('div');
  wrapper.className = 'bot-message';
  wrapper.textContent = text;
  chatBox.appendChild(wrapper);
  chatBox.scrollTop = chatBox.scrollHeight;
  return wrapper;
}

function appendBotTyping(){
  if (!chatBox) return null;
  const el = document.createElement('div');
  el.className = 'bot-message typing';
  el.id = 'bot-typing-' + Date.now();
  el.textContent = 'Thinking...';
  chatBox.appendChild(el);
  chatBox.scrollTop = chatBox.scrollHeight;
  return el.id;
}

function removeElementById(id){
  if (!chatBox || !id) return;
  const el = document.getElementById(id);
  if (el) el.remove();
}

/* ---------------
   ENTER KEY BIND
   --------------- */
function handleKey(e){
  if (!e) return;
  if (e.key === 'Enter') {
    // if file input is focused do nothing; else send
    sendMessage();
  }
}
window.handleKey = handleKey;

/* ---------------
   VOICE INPUT
   --------------- */
(function voiceSetup(){
  if (!micBtn || !('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
    if (micBtn) micBtn.style.opacity = 0.45;
    return;
  }
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.addEventListener('result', (e) => {
    const transcript = e.results?.[0]?.[0]?.transcript;
    if (transcript && userInput) {
      userInput.value = transcript;
      sendMessage();
    }
  });
  recognition.addEventListener('error', (e) => {
    console.warn('Speech error', e);
    alert('Voice input error: ' + (e.error || 'unknown'));
  });

  micBtn.addEventListener('click', ()=>{
    try {
      recognition.start();
    } catch (err) {
      console.warn('recognition start error', err);
    }
  });
})();

/* ---------------
   CHAT UTILITIES: save / copy / clear if buttons exist
   --------------- */
(function chatUtilities(){
  // Save chat (if #saveChat exists as a button)
  const saveBtn = document.getElementById('saveChat');
  if (saveBtn){
    saveBtn.addEventListener('click', ()=>{
      const lines = [];
      chatBox?.querySelectorAll('.user-message, .bot-message').forEach(m=>{
        lines.push(m.textContent || '');
      });
      const blob = new Blob([lines.join('\n\n')], {type: 'text/plain'});
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `rag-chat-${Date.now()}.txt`;
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(a.href);
    });
  }

  const copyBtn = document.getElementById('copyChat');
  if (copyBtn){
    copyBtn.addEventListener('click', async ()=>{
      try {
        let text = '';
        chatBox?.querySelectorAll('.user-message, .bot-message').forEach(m=>{
          text += (m.textContent || '') + '\n\n';
        });
        await navigator.clipboard.writeText(text);
        alert('Chat copied to clipboard');
      } catch (err) {
        alert('Copy failed: ' + (err.message || err));
      }
    });
  }

  const clearBtn = document.getElementById('clearChat');
  if (clearBtn){
    clearBtn.addEventListener('click', ()=>{
      if (!confirm('Clear the current chat?')) return;
      if (chatBox) chatBox.innerHTML = '';
      if (retrievedEl) retrievedEl.textContent = '';
    });
  }
})();

/* ---------------
   LOGIN (Google Docs fetch) helper
   --------------- */
function loginWithGoogle(){
  // existing backend route /fetch_docs will start Google OAuth flow
  window.location.href = '/fetch_docs';
}
window.loginWithGoogle = loginWithGoogle;

/* ---------------
   FOOTER YEAR
   --------------- */
if (yearEl) yearEl.textContent = new Date().getFullYear();

/* expose sendMessage so inline onclicks work */
window.sendMessage = sendMessage;

/* Good to go! */
console.log('WayneTech main.js loaded — UI features ready.');
