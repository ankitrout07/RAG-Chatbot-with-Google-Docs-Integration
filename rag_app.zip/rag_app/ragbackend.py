from flask import Flask, render_template, request, jsonify
from google_auth import fetch_google_docs, extract_doc_text
from rag_pipeline import setup_vector_store, generate_answer

app = Flask(__name__)

# Cache to hold docs content
knowledge_base = None

@app.route('/')
def home():
    return jsonify({"message": "RAG Chatbot Backend Running 🚀"})

@app.route('/fetch_docs')
def fetch_docs():
    docs = fetch_google_docs()
    return jsonify(docs)

@app.route('/load_docs', methods=['POST'])
def load_docs():
    global knowledge_base
    doc_ids = request.json.get("doc_ids", [])
    contents = [extract_doc_text(doc_id) for doc_id in doc_ids]
    knowledge_base = setup_vector_store(contents)
    return jsonify({"message": f"{len(doc_ids)} docs added to knowledge base"})

@app.route('/ask', methods=['POST'])
def ask():
    global knowledge_base
    if not knowledge_base:
        return jsonify({"answer": "No documents loaded yet."})

    user_query = request.json['query']
    answer = generate_answer(user_query, knowledge_base)
    return jsonify({"answer": answer})

if __name__ == '__main__':
    app.run(debug=True)
