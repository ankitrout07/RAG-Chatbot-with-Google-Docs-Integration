from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

def fetch_google_docs():
    SCOPES = ['https://www.googleapis.com/auth/drive.readonly']
    flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
    creds = flow.run_local_server(port=8080)

    service = build('drive', 'v3', credentials=creds)
    results = service.files().list(
        q="mimeType='application/vnd.google-apps.document'",
        pageSize=10, fields="files(id, name)").execute()
    items = results.get('files', [])
    return items

def extract_doc_text(doc_id):
    SCOPES = ['https://www.googleapis.com/auth/documents.readonly']
    flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
    creds = flow.run_local_server(port=8081)

    service = build('docs', 'v1', credentials=creds)
    document = service.documents().get(documentId=doc_id).execute()

    text = ""
    for content in document.get('body').get('content', []):
        paragraph = content.get('paragraph')
        if not paragraph:
            continue
        for elem in paragraph.get('elements', []):
            if 'textRun' in elem:
                text += elem['textRun']['content']
    return text
